{{-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>Show Car Data</title>
</head>
<body>
    <div class="container">
        <h2>Car Data</h2>
        <p>Title: {{ $data['carTitle'] }}</p>
        <p>Price: {{ $data['price'] }}</p>
        <p>Description: {{ $data['description'] }}</p>
        <p>Published: {{ isset($data['remember']) ? 'Yes' : 'No' }}</p>
    </div>
</body>
</html> --}}
